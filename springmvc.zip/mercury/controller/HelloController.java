package com.mercury.controller;

//controller class: handle request and send response back

import javafx.scene.input.DataFormat;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.zip.DataFormatException;

//GET /hello
@Controller
@RequestMapping(value = "/hello")
public class HelloController {
    //how to handle get request to "/hello"
//    @RequestMapping(method = RequestMethod.GET)
//    public String getHello() {
//        return "welcome"; //view name
//    }

    @RequestMapping(method = RequestMethod.GET)
    public ModelAndView getHello() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("welcome");
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        String current = dateFormat.format(date);
        modelAndView.addObject("current", current);
        return modelAndView;
    }


}
