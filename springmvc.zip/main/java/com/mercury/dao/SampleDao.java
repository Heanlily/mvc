package com.mercury.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mercury.bean.Sample;
import com.mercury.util.JdbcUtil;
import org.springframework.stereotype.Component;

@Component
public class SampleDao {

	// define methods to CRUD sample table.
	// Dao: data access object

	public List<Sample> getSamples() {
		List<Sample> list = new ArrayList<>();
		try (Connection conn = JdbcUtil.getConnection();) {
			String sql = "SELECT * FROM sample";
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Sample s = new Sample(rs.getString("name"), rs.getInt("age"));
				list.add(s);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public void updateSample(Sample sample) {

	}

	public boolean addSample(Sample sample) {
		try (Connection conn = JdbcUtil.getConnection();) {
			String sql = "INSERT INTO sample VALUES(?, ?)";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, sample.getName());
			ps.setInt(2, sample.getAge());
			ps.executeQuery();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	public void deleteSample(String name) {

	}

}
