package com.mercury.controller;

import com.mercury.bean.Sample;
import com.mercury.dao.SampleDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
@RequestMapping(value = "/sample")

public class SampleController {
        @Autowired
        SampleDao sampleDao;
//        @RequestMapping(method = RequestMethod.GET)
//        public ModelAndView getSample() {
//            ModelAndView modelAndView = new ModelAndView();
//            modelAndView.setViewName("all-samples");
//            //SampleDao sampleDao = new SampleDao();
//            //List<Sample> current = sampleDao.getSamples();
//            modelAndView.addObject("samples", sampleDao.getSamples());
//            return modelAndView;
            //how to return Json format data?
            //reason: angular/react are expecting JSON data to dynamically build
            //fronted pages in the client slide.
            @RequestMapping(method = RequestMethod.GET)
            @ResponseBody //ask spring to convert JAVA to Json
            public List<Sample> getSamples() {
                List<Sample> sampleList = sampleDao.getSamples();
                //List of java objects -> JSON
                return sampleList;

        }


}

